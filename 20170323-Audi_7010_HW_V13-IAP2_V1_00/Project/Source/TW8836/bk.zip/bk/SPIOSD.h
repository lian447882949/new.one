#ifndef __SPIOSD_H__
#define __SPIOSD_H__


#undef  EXTERN


#ifdef  __SPIOSD_C__
#define EXTERN
#else
#define EXTERN extern
#endif


#include <stdio.h>
#include "gd32f1x0.h"
#include "TW8836.h"


typedef struct __SPIOSD_LUT_STRUCT__
{
    uint8_t  type;
    uint16_t offset;
    uint16_t size;
    uint32_t addr;
    uint8_t  alpha;
} SPIOSD_LUT;


typedef struct __SPIOSD_RLC_STRUCT__
{
    uint8_t winno;
    uint8_t bpp;
    uint8_t counter;
} SPIOSD_RLC;


typedef struct __SPIOSD_STRUCT__
{
    uint8_t    *reg[9];
    SPIOSD_LUT  lut[9];
    SPIOSD_RLC  rlc[2];
} SPIOSD;


#define SPIOSD_START        REG400
#define SPIOSD_WIN0_START   REG420
#define SPIOSD_WIN1_START   REG440
#define SPIOSD_WIN2_START   REG450
#define SPIOSD_WIN3_START   REG460
#define SPIOSD_WIN4_START   REG470
#define SPIOSD_WIN5_START   REG480
#define SPIOSD_WIN6_START   REG490
#define SPIOSD_WIN7_START   REG4A0
#define SPIOSD_WIN8_START   REG4B0


#define SPIOSD_LUT_BYTE     0x01
#define SPIOSD_LUT_ADDR     0x00
#define SPIOSD_LUT_MASK     0x01


#define SPIOSD_LUT_WEN              0x80    /*Enable Look up table write access*/
#define SPIOSD_LUT_INC_ADDR         0x40    /*Address pointer inc. by 1 after each LUT data port write*/
#define SPIOSD_LUT_INC_BYTE         0x20    /*Byte    pointer inc. by 1 after each LUT data port write*/
#define SPIOSD_LUT_ADDR_H           0x08    /*MSB of the address pointer to one of the 512 entries of the LUT*/
#define SPIOSD_LUT_SEL              0x04    /*0:Select 512*8 LUT, 1:Select 256*8 LUT*/
#define SPIOSD_LUT_BYT              0x03    /*Byte pointer for the LUT access*/


#define SPIOSD_WIN_ENABLE           0x00
#define SPIOSD_WIN_WINDOW           0x01
#define SPIOSD_WIN_BUFFERSTART      0x07
#define SPIOSD_WIN_BUFFERSTART_BIT  0x0A
#define SPIOSD_WIN_DISPSIZE         0x0A
#define SPIOSD_WIN_DISPOFFSET       0x0D    /*Only Win0*/
#define SPIOSD_WIN_ALPHA            0x0C
#define SPIOSD_WIN_LUT_PTR          0x0D
#define SPIOSD_WIN_FILLCOLOR        0x0E
#define SPIOSD_WIN_ANIMATION        0x12    /*Only Win0*/



EXTERN void SpiOsdEnable( uint8_t en );
EXTERN void SpiOsdSetDeValue( void );
EXTERN void SpiOsdWinEnable( uint8_t winno, uint8_t en );
EXTERN void SpiOsdAlphaBlending( uint8_t winno, uint8_t en, uint8_t mode, uint8_t alpha );
EXTERN void SpiOsdSetBitsPixel( uint8_t winno, uint8_t bpp );
EXTERN void SpiOsdLutOffset( uint8_t winno,  uint8_t lut_offset );
EXTERN void SpiOsdBuffWidth( uint8_t winno, uint16_t w, uint16_t h );
EXTERN void SpiOsdSpiStartAddress( uint8_t winno, uint32_t address );
EXTERN void SpiOsdWindowPosAndSize( uint8_t winno, uint16_t start_h, uint16_t start_v, uint16_t len_h, uint16_t len_v );
EXTERN void SpiOsdZoom( uint8_t winno, uint8_t en );
EXTERN void SpiOsdFillColor( uint8_t winno, uint8_t en, uint8_t fill_color );
EXTERN void SpiOsdSetLut( uint8_t winno, uint8_t type, uint16_t lut_offset, uint16_t size, uint32_t addr, uint8_t alpha );
EXTERN void SpiOsdSetRlc( uint8_t winno, uint8_t bpp, uint8_t counter );
EXTERN void SpiOsdInit( void );
EXTERN void SpiOsdClrReg( void );
EXTERN void SpiOsdClrLut( void );
EXTERN void SpiOsdClrRlc( void );
EXTERN void SpiOsdUpdateReg( uint8_t begin_winno, uint8_t end_winno );
EXTERN void SpiOsdUpdateLut( uint8_t winno, uint8_t alpha );
EXTERN void SpiOsdUpdateRlc( void );


#endif


