#define __TSC_C__


#include "TSC.h"
#include "TW8836.h"



