#ifndef __TSC_H__
#define __TSC_H__


#undef  EXTERN


#ifdef  __TSC_C__
#define EXTERN
#else
#define EXTERN extern
#endif


#include <stdio.h>
#include "gd32f1x0.h"


#endif

