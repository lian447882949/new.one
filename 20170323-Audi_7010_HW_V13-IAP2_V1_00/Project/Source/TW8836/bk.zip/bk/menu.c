#define __MENU_C__


#include "menu.h"
#include "SPIFlash.h"
#include "SPIOSD.h"
#include "TW8836.h"


RLE2_HEADER  gtRLE2Header;
IMAGE_HEADER gtImageHeader;


void Info_To_Header( IMAGE_INFO *tImageInfo )
{
    IMAGE_HEADER *tImageHeader = &gtImageHeader;

    tImageHeader->lut_type = tImageInfo->lut_type;
    tImageHeader->bpp      = tImageInfo->rle >> 0x04;
    tImageHeader->rle      = tImageInfo->rle &  0x0F;
    tImageHeader->dx       = tImageInfo->dx;
    tImageHeader->dy       = tImageInfo->dy;
    tImageHeader->lut_size = 0x004 << tImageHeader->bpp;
}


void RLE2_To_Header( RLE2_HEADER *tRLE2Header )
{
    IMAGE_HEADER *tImageHeader;

    uint8_t  bpp;
    uint16_t colors;

    tImageHeader = &gtImageHeader;

    tImageHeader->lut_type = tRLE2Header->lut_format & 0x01;

    colors = (uint16_t)tRLE2Header->lut_colors + 1;

    for(bpp = 0; bpp < 9; bpp++)
    {
        if(colors & 0x01) break;
        colors>>=1;
    }

    tImageHeader->bpp      = bpp;
    tImageHeader->rle      = tRLE2Header->rledata_cnt & 0x0F;
    tImageHeader->dx       = tRLE2Header->w;
    tImageHeader->dy       = tRLE2Header->h;
    tImageHeader->lut_size = 0x004 << bpp;
}


void MenuReadRLEHeader( uint32_t ulAddress, RLE2_HEADER *tRLE2Header )
{
    uint32_t ulTemp = 0;

    TW8836_WaitVBlank(1);

    SpiFlashReadRLE2Header((uint8_t *)tRLE2Header, ulAddress, sizeof(RLE2_HEADER));

    if((tRLE2Header->id[0] != 'I') || (tRLE2Header->id[1] != 'T'))
    {
        printf("\r\nMenu Read RLE Header Failed.");
        return;
    }

    ulTemp = tRLE2Header->size;

    tRLE2Header->size   = ulTemp & 0x000000FF;
    tRLE2Header->size <<= 8; ulTemp >>= 8;
    tRLE2Header->size  |= ulTemp & 0x000000FF;
    tRLE2Header->size <<= 8; ulTemp >>= 8;
    tRLE2Header->size  |= ulTemp & 0x000000FF;
    tRLE2Header->size <<= 8; ulTemp >>= 8;
    tRLE2Header->size  |= ulTemp & 0x000000FF;
}


void MenuPrepareImageHeader( IMAGE_ITEM_INFO *tImageItemInfo )
{
    IMAGE_HEADER *tImageHeader = &gtImageHeader;

    if(tImageItemInfo->type == 1)
    {
        MenuReadRLEHeader(tImageItemInfo->addr, &gtRLE2Header);

        RLE2_To_Header(&gtRLE2Header);

        tImageHeader->lut_addr = tImageItemInfo->addr + MRLE_INFO_SIZE;
        tImageHeader->img_addr = tImageItemInfo->addr + tImageHeader->lut_size + MRLE_INFO_SIZE;
    }
    else if(tImageItemInfo->type == 2)
    {
        Info_To_Header(tImageItemInfo->info);

        tImageHeader->lut_addr  = tImageItemInfo->addr;
        tImageHeader->img_addr  = tImageItemInfo->addr + tImageHeader->lut_size;
        tImageHeader->lut_addr += MRLE_INFO_SIZE;
        tImageHeader->img_addr += MRLE_INFO_SIZE;
    }
    else
    {
        Info_To_Header(tImageItemInfo->info);

        tImageHeader->lut_addr = tImageItemInfo->addr;
        tImageHeader->img_addr = tImageItemInfo->addr + tImageHeader->lut_size;
    }
}



#define IMAGE_OFFSET_ADDR   0x0


#define WIN_DEMO            0x01


IMAGE_ITEM_INFO image01 = {1, IMAGE_OFFSET_ADDR + 0x000000, NULL, 0xFF};    // image01 


void MenuStart( void )
{
    SpiOsdInit();

    SpiOsdSetDeValue();
}


void MenuDemo( void )
{
    IMAGE_ITEM_INFO *tImage;
    IMAGE_HEADER    *tImageHeader = &gtImageHeader;

    IMAGE_ITEM_INFO *tImageArray[1] ={ &image01 };

    tImage = tImageArray[0];

    TW8836_WaitVBlank(1);

    SpiOsdEnable(0);

    MenuPrepareImageHeader(tImage);

    SpiOsdSpiStartAddress(WIN_DEMO, tImageHeader->img_addr);

    SpiOsdBuffWidth(WIN_DEMO, tImageHeader->dx, tImageHeader->dy);

    SpiOsdWindowPosAndSize(WIN_DEMO, 0, 0, tImageHeader->dx, tImageHeader->dy);

    SpiOsdSetBitsPixel(WIN_DEMO, tImageHeader->bpp);

    SpiOsdLutOffset(WIN_DEMO, 0);

    SpiOsdWinEnable(WIN_DEMO, 1);

    if(tImageHeader->rle)
    {
        SpiOsdSetRlc(WIN_DEMO, tImageHeader->bpp, tImageHeader->rle);
    }
    else
    {
        SpiOsdClrRlc();
    }

    TW8836_WaitVBlank(1);

    SpiOsdUpdateReg(WIN_DEMO, WIN_DEMO);
    
    SpiOsdUpdateRlc();

    SpiOsdEnable(1);

    SpiOsdSetLut(WIN_DEMO, tImageHeader->lut_type, 0, tImageHeader->lut_size, tImageHeader->lut_addr, tImage->alpha);
    SpiOsdUpdateLut(WIN_DEMO, 0);
}


