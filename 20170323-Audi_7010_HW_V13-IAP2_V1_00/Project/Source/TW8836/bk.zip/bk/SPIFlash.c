#define __SPIFLASH_C__


#include "kernel.h"
#include "SPIFlash.h"
#include "TW8836.h"


uint8_t gucSpiFlashVendor    = SPI_FLASH_VENDOR_UNKNOW;
uint8_t gucSpiFlash4ByteMode = 0x00;


uint8_t SPICMD_x_READ  = 0x00;
uint8_t SPICMD_x_BYTES = 0x00;


void SpiFlashDmaControl( uint8_t ucDestination, uint8_t ucAccessMode, uint8_t ucCount )
{
    uint8_t ucREG4C3 = 0;

    ucREG4C3 = ((ucDestination << 6) & 0xC0) | ((ucAccessMode << 4) & 0x30) | (ucCount & 0x0F);

    TW8836_Write(REG4C3, ucREG4C3);
}


uint8_t SpiFlashBusyControl( uint8_t ucCommand )
{
    uint8_t temp = 0;

    switch(ucCommand)
    {
        case FLASH_CMD_PP       :   temp = 0x02;    break;
        case FLASH_CMD_READ     :
        case FLASH_CMD_FAST_READ:
        case FLASH_CMD_4READ    :
        case FLASH_CMD_WRSR     :   temp = 0x04;    break;
        case FLASH_CMD_SE       :
        case FLASH_CMD_BE       :
        case FLASH_CMD_BE_32K   :
        case FLASH_CMD_CE       :   temp = 0x06;    break;
        default:
            break;
    }

    return temp;
}


uint8_t SpiFlashReadChipRegister( DMA_RW_CHIP_REGISTER *tDMARWChipRegister )
{
    uint8_t  i = 0, ucREG4C4 = 0;

    TW8836_WritePage(TW8836_PAGE4_SPI_MCU);

    SpiFlashDmaControl(DMA_RW_DEST_CHIPREG, DMA_RW_MODE_INCREASE, tDMARWChipRegister->w_size + 0x01);

    /*DMA Page & Index Register*/
    TW8836_Write(REG4C6, DMA_RW_BUFFER_REG_PAGE);
    TW8836_Write(REG4C7, DMA_RW_BUFFER_REG_INDEX);

    /*DMA Lenght HIGH , MID , LOW Byte Register*/
    TW8836_Write(REG4DA, 0x00);
    TW8836_Write(REG4C8, 0x00);
    TW8836_Write(REG4C9, tDMARWChipRegister->r_size);

    /*DMA Command Buffer Register*/
    TW8836_Write(REG4CA, tDMARWChipRegister->command);

    for(i = 0; i < tDMARWChipRegister->w_size; i++)
    {
        TW8836_Write(REG4CB + i, tDMARWChipRegister->parameter[i]);
    }

    ucREG4C4 |= SpiFlashBusyControl(tDMARWChipRegister->command);

    TW8836_Write(REG4C4, ucREG4C4 | 0x01);   /* Start command execution. Self cleared */

    while(TW8836_Read(REG4C4) & 0x01);

    /*DMA Read/Write Buffer Register*/
    for(i = 0; i < tDMARWChipRegister->r_size; i++)
    {
        tDMARWChipRegister->buffer[i] = TW8836_Read(REG4D0 + i);
    }

    return 0;
}


void SpiFlashReadRLE2Header( uint8_t *dest_loc, uint32_t src_loc, uint16_t size )
{
    uint16_t i = 0, j = 0, rSize = 0;

    uint8_t *ptr;

    uint8_t ucREG4C1 = 0;

    ptr = (uint8_t *)dest_loc;

    TW8836_WritePage(TW8836_PAGE4_SPI_MCU);

    ucREG4C1 = TW8836_Read(REG4C1);

    /*DMA Start Mode : Immediately*/
    TW8836_Write(REG4C1, ucREG4C1 & 0xFE);

    SpiFlashDmaControl(DMA_RW_DEST_CHIPREG, DMA_RW_MODE_INCREASE, 0x05);

    /*DMA Page & Index Register*/
    TW8836_Write(REG4C6, DMA_RW_BUFFER_REG_PAGE);
    TW8836_Write(REG4C7, DMA_RW_BUFFER_REG_INDEX);

    /*DMA Command Buffer Register*/
    TW8836_Write(REG4CA, FLASH_CMD_FAST_READ);      /*SPI Command : Fast Read*/

    for(i = 0; i < size; i+=8)
    {
        /*DMA Command Buffer Register*/
        TW8836_Write(REG4CB, (uint8_t)((src_loc + i) >> 0x10));
    	TW8836_Write(REG4CC, (uint8_t)((src_loc + i) >> 0x08));
    	TW8836_Write(REG4CD, (uint8_t)((src_loc + i) >> 0x00));

        if(i+0x08 <= size) rSize = 0x08;
        else               rSize = size - i;

        /*DMA Lenght HIGH , MID , LOW Byte Register*/
        TW8836_Write(REG4DA, 0x00);
        TW8836_Write(REG4C8, 0x00);
        TW8836_Write(REG4C9, rSize);

        /*SPI Flash Read Mode : Fast*/
        TW8836_Write(REG4C0, (TW8836_Read(REG4C0) & 0xF8) | 0x01);

        /*Flash Busy Control : Busy Check And DMA Start Read*/
        TW8836_Write(REG4C4, 0x05);

        /*Wait DMA Execution Finished*/
        while(TW8836_Read(REG4C4) & 0x01);

        /*SPI Flash Read Mode : QUAD-IO*/
        TW8836_Write(REG4C0, (TW8836_Read(REG4C0) & 0xF8) | 0x05);

        for(j = 0; j < rSize; j++)
        {
            /*DMA Read/Write Buffer Register*/
            *ptr++ = TW8836_Read(REG4D0 + j);
        }
    }

    /*Restore The Register Value*/
    TW8836_Write(REG4C1, ucREG4C1);
}


void SpiFlashInitQuad( void )
{
    uint8_t status = 0, value = 0;

    uint8_t ManufacturerID, MemoryType, MemoryDensity;

    DMA_RW_CHIP_REGISTER tDMARWChipRegister;

    tDMARWChipRegister.command = FLASH_CMD_RDID;
    tDMARWChipRegister.r_size  = 0x03;
    tDMARWChipRegister.w_size  = 0x00;

    status = SpiFlashReadChipRegister(&tDMARWChipRegister);

    if(status)
    {
        printf("\r\nRead Flash's Identification Fail.");
    }

    ManufacturerID = tDMARWChipRegister.buffer[0];
    MemoryType     = tDMARWChipRegister.buffer[1];
    MemoryDensity  = tDMARWChipRegister.buffer[2];

    printf("\r\nSPI Flash JEDEC ID : 0x%x, 0x%x, 0x%x", ManufacturerID, MemoryType, MemoryDensity);

    switch(ManufacturerID)
    {
        case 0x1C:
            gucSpiFlashVendor = SPI_FLASH_VENDOR_EON;

            if(MemoryType == 0x70 && MemoryDensity == 0x19)
            {
                gucSpiFlashVendor = SPI_FLASH_VENDOR_EON_256;
            }
            break;

        default:
            printf("\r\nUnknow SPI Flash.");
            break;
    }

    /*Read Status Register*/
    if(ManufacturerID == 0x1C || ManufacturerID == 0xC2)    /* EON:0x1C , MX:0xC2 */
    {
        tDMARWChipRegister.command = FLASH_CMD_RDSR;
        tDMARWChipRegister.r_size  = 0x01;
        tDMARWChipRegister.w_size  = 0x00;

        status = SpiFlashReadChipRegister(&tDMARWChipRegister);

        value  = tDMARWChipRegister.buffer[0];
    }

    printf("\r\nSPI Flash Status Register Value : 0x%x", value);

    if(value) return;


    /* Enable Quad IO Mode */
    if(ManufacturerID == 0x1C || ManufacturerID == 0xC2)    /* EON:0x1C , MX:0xC2 */
    {
        tDMARWChipRegister.command = FLASH_CMD_WREN;
        tDMARWChipRegister.r_size  = 0x00;
        tDMARWChipRegister.w_size  = 0x00;

        SpiFlashReadChipRegister(&tDMARWChipRegister);


        tDMARWChipRegister.command = FLASH_CMD_WRSR;
        tDMARWChipRegister.r_size  = 0x00;
        tDMARWChipRegister.w_size  = 0x01;
        tDMARWChipRegister.parameter[0] = 0x40;

        SpiFlashReadChipRegister(&tDMARWChipRegister);


        tDMARWChipRegister.command = FLASH_CMD_WRDI;
        tDMARWChipRegister.r_size  = 0x00;
        tDMARWChipRegister.w_size  = 0x00;

        SpiFlashReadChipRegister(&tDMARWChipRegister);
    }

    printf("\r\nSPI Flash Quad IO Mode Enable.");
}


void SpiFlashSetReadMode( uint8_t ucMode )
{
    TW8836_WritePage(TW8836_PAGE4_SPI_MCU);

    TW8836_Write(REG4C0, (TW8836_Read(REG4C0) & 0xF8) | ucMode);

    switch(ucMode)
    {
        case SPI_RD_MODE_SLOW:    SPICMD_x_READ = 0x03; SPICMD_x_BYTES = 0x04; break;
        case SPI_RD_MODE_FAST:    SPICMD_x_READ = 0x0B; SPICMD_x_BYTES = 0x05; break;
        case SPI_RD_MODE_DUAL:    SPICMD_x_READ = 0x3B; SPICMD_x_BYTES = 0x05; break;
        case SPI_RD_MODE_QUAD:    SPICMD_x_READ = 0x6B; SPICMD_x_BYTES = 0x05; break;
        case SPI_RD_MODE_DUAL_IO: SPICMD_x_READ = 0xBB; SPICMD_x_BYTES = 0x05; break;
        case SPI_RD_MODE_QUAD_IO: SPICMD_x_READ = 0xEB; SPICMD_x_BYTES = 0x07; break;
        case SPI_RD_MODE_D_QUAL:  SPICMD_x_READ = 0x03; SPICMD_x_BYTES = 0x05; break;
        default:
            break;
    }
}


void SpiFlashSet4ByteMode( uint8_t ucMode )
{
    uint8_t ucCommand = 0;
    DMA_RW_CHIP_REGISTER tDMARWChipRegister;

    if(ucMode)
    {
        if(gucSpiFlash4ByteMode == 0)
        {
            gucSpiFlash4ByteMode = 1;
            ucCommand = FLASH_CMD_EN4B;
        }
    }
    else
    {
        if(gucSpiFlash4ByteMode == 1)
        {
            gucSpiFlash4ByteMode = 0;
            ucCommand = FLASH_CMD_EX4B;
        }
    }

    if(ucCommand)
    {
        tDMARWChipRegister.command = ucCommand;
        tDMARWChipRegister.r_size  = 0x00;
        tDMARWChipRegister.w_size  = 0x00;
        
        SpiFlashReadChipRegister(&tDMARWChipRegister);
    }
}


void SpiFlashInit( void )
{
    SpiFlashInitQuad();

    if(gucSpiFlashVendor == SPI_FLASH_VENDOR_EON_256)
    {
        SpiFlashSet4ByteMode(1);

        if(gucSpiFlash4ByteMode)
        {
            printf("\r\nSPI Flash Enter 4-Byte Mode.");
        }
    }

    SpiFlashSetReadMode(SPI_READ_MODE);

    printf("\r\nSPI Flash Init Finished.");
}


