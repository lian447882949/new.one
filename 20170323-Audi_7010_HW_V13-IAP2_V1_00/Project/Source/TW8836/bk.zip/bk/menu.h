#ifndef __MENU_H__
#define __MENU_H__


#undef  EXTERN


#ifdef  __MENU_C__
#define EXTERN
#else
#define EXTERN extern
#endif


#include <stdio.h>
#include "gd32f1x0.h"


typedef struct __RLE2_HEADER_STRUCT__
{
    uint8_t  id[2];

    uint8_t  op_bmpbits;
    uint8_t  rledata_cnt;

    uint16_t w;
    uint16_t h;

    uint32_t size;

    uint8_t  lut_format;
    uint8_t  lut_colors;

    uint8_t  dummy[2];
} RLE2_HEADER;


typedef struct __IMAGE_HEADER_STRUCT__
{
    uint32_t lut_addr;
    uint32_t img_addr;

    uint8_t  lut_type;  /*0:lut,address method; 1:luts,byte pointer method*/
    uint8_t  bpp;       /*bit per pixel*/
    uint8_t  rle;       /*compression ration,upper:bpp, bottom:RLE counter*/
    uint16_t dx;        /*width (pixel)*/
    uint16_t dy;        /*height(pixel)*/
    uint16_t lut_size;  /*we don't need it. we can assume lut size & image size*/
} IMAGE_HEADER;


typedef struct __IMAGE_INFO_STRUCT__
{
    uint8_t lut_type;   /*0:lut,address method; 1:luts,byte pointer method*/
    uint8_t rle;        /*upper:bpp, bottom:RLE counter*/
    uint16_t dx;        /*width*/
    uint16_t dy;        /*height*/
} IMAGE_INFO;


typedef struct __IMAGE_ITEM_INFO_STRUCT__
{
    uint8_t     type;   /*0:LUT+Image, 1:Header+LUT+Image, 2:Image Only, 3:LTU Only, 4:Header Only*/
    uint32_t    addr;   /*Absolute Location On SPI Flash*/
    IMAGE_INFO *info;
    uint8_t     alpha;  /*Alpha Index, 0xFF:Ignore*/
} IMAGE_ITEM_INFO;



#define MRLE_INFO_SIZE  0x10


EXTERN void MenuStart( void );
EXTERN void MenuDemo( void );


#endif


