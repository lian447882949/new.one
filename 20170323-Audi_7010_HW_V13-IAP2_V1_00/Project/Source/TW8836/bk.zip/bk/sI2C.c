#define __SI2C_C__


#include "kernel.h"
#include "sI2C.h"


static void sI2cSdaIn( void )
{
    GPIO_InitPara   GPIO_InitParaStruct;

    RCC_AHBPeriphClock_Enable(RCC_AHBPERIPH_GPIOB, ENABLE);

    GPIO_InitParaStruct.GPIO_Pin   = sI2C_SDA_PIN;
    GPIO_InitParaStruct.GPIO_Mode  = GPIO_MODE_IN;
    GPIO_InitParaStruct.GPIO_Speed = GPIO_SPEED_50MHZ;
    GPIO_InitParaStruct.GPIO_OType = GPIO_OTYPE_OD;
    GPIO_InitParaStruct.GPIO_PuPd  = GPIO_PUPD_NOPULL;
    GPIO_Init(sI2C_PORT, &GPIO_InitParaStruct);
}


static void sI2cSdaOut( void )
{
    GPIO_InitPara   GPIO_InitParaStruct;

    RCC_AHBPeriphClock_Enable(RCC_AHBPERIPH_GPIOB, ENABLE);

    GPIO_InitParaStruct.GPIO_Pin   = sI2C_SDA_PIN;
    GPIO_InitParaStruct.GPIO_Mode  = GPIO_MODE_OUT;
    GPIO_InitParaStruct.GPIO_Speed = GPIO_SPEED_50MHZ;
    GPIO_InitParaStruct.GPIO_OType = GPIO_OTYPE_OD;
    GPIO_InitParaStruct.GPIO_PuPd  = GPIO_PUPD_NOPULL;
    GPIO_Init(sI2C_PORT, &GPIO_InitParaStruct);
}


void sI2cInit( void )
{
    GPIO_InitPara   GPIO_InitParaStruct;

    RCC_AHBPeriphClock_Enable(RCC_AHBPERIPH_GPIOB, ENABLE);

    GPIO_InitParaStruct.GPIO_Pin   = sI2C_SCL_PIN | sI2C_SDA_PIN;
    GPIO_InitParaStruct.GPIO_Mode  = GPIO_MODE_OUT;
    GPIO_InitParaStruct.GPIO_Speed = GPIO_SPEED_50MHZ;
    GPIO_InitParaStruct.GPIO_OType = GPIO_OTYPE_OD;
    GPIO_InitParaStruct.GPIO_PuPd  = GPIO_PUPD_NOPULL;
    GPIO_Init(sI2C_PORT, &GPIO_InitParaStruct);

    sI2C_SCL_SET;
    sI2C_SDA_SET;
}


static void sI2cStart( void )
{
    sI2cSdaOut();

    sI2C_SDA_SET;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SCL_SET;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SDA_CLR;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SCL_CLR;   Delay(5 * DELAY_LEVEL_US);
}


static void sI2cStop( void )
{
    sI2cSdaOut();

    sI2C_SCL_CLR;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SDA_CLR;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SCL_SET;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SDA_SET;   Delay(5 * DELAY_LEVEL_US);
}


static void sI2cAck( uint8_t ucAck )
{
    if(ucAck)   sI2C_SDA_SET;   /*NACK*/
    else        sI2C_SDA_CLR;   /*ACK*/

    Delay(5 * DELAY_LEVEL_US);

    sI2C_SCL_SET;   Delay(5 * DELAY_LEVEL_US);

    if(ucAck)   /*NACK*/
    sI2C_SDA_CLR;   Delay(5 * DELAY_LEVEL_US);

    sI2C_SCL_CLR;   Delay(5 * DELAY_LEVEL_US);
}


static uint8_t sI2cDataSend( uint8_t ucByte )
{
    uint8_t i = 0, ack = 0;

    sI2C_SCL_CLR;

    for(i = 0; i < 8; i++)
    {
        if((ucByte << i) & 0x80)
        {
            sI2C_SDA_SET;
        }
        else
        {
            sI2C_SDA_CLR;
        }

        Delay(2 * DELAY_LEVEL_US);

        sI2C_SCL_SET;   Delay(5 * DELAY_LEVEL_US);
        sI2C_SCL_CLR;
    }

    Delay(2 * DELAY_LEVEL_US);

    sI2C_SDA_SET;   Delay(5 * DELAY_LEVEL_US);
    sI2C_SCL_SET;   Delay(5 * DELAY_LEVEL_US);

    sI2cSdaIn();

    if(sI2C_SDA_GET == 1)   ack = 0;
    else                    ack = 1;

    sI2cSdaOut();

    sI2C_SCL_CLR;
    
    return ack;
}


static uint8_t sI2cDataReceive( void )
{
    uint8_t i = 0, ucByte = 0;

    sI2cSdaIn();

    for(i = 0; i < 8; i++)
    {
        sI2C_SCL_CLR;   Delay(5 * DELAY_LEVEL_US);
        sI2C_SCL_SET;   Delay(2 * DELAY_LEVEL_US);

        ucByte <<= 1;

        if(sI2C_SDA_GET == 1) ucByte++;

        Delay(2 * DELAY_LEVEL_US);
    }

    sI2cSdaOut();

    sI2C_SCL_CLR;   Delay(5 * DELAY_LEVEL_US);

    return ucByte;
}


uint8_t sI2cReadByte( uint8_t sla, uint8_t suba )
{
    uint8_t ucByte = 0;

    sI2cStart();

    if(sI2cDataSend(sla)  == 0) return 0;
    if(sI2cDataSend(suba) == 0) return 0;

    sI2cStop();


    sI2cStart();

    if(sI2cDataSend(sla + 1) == 0) return 0;

    ucByte = sI2cDataReceive();

    sI2cAck(1);

    sI2cStop();

    return ucByte;
}


uint8_t sI2cWriteByte( uint8_t sla, uint8_t suba, uint8_t dat )
{
    sI2cStart();

    if(sI2cDataSend(sla)  == 0) return 0;
    if(sI2cDataSend(suba) == 0) return 0;
    if(sI2cDataSend(dat)  == 0) return 0;

    sI2cStop();

    return SUCCESS;
}


