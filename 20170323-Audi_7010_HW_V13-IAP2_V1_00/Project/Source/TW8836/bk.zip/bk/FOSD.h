#ifndef __FOSD_H__
#define __FOSD_H__


#undef  EXTERN


#ifdef  __FOSD_C__
#define EXTERN
#else
#define EXTERN extern
#endif


#include <stdio.h>
#include "gd32f1x0.h"


#endif

