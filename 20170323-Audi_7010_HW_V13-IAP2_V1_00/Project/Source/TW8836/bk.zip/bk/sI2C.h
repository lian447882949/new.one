#ifndef __SI2C_H__
#define __SI2C_H__


#undef  EXTERN


#ifdef  __SI2C_C__
#define EXTERN
#else
#define EXTERN extern
#endif


#include <stdio.h>
#include "gd32f1x0.h"


#define sI2C_PORT       GPIOB
#define sI2C_SCL_PIN    GPIO_PIN_6
#define sI2C_SDA_PIN    GPIO_PIN_7

#define sI2C_SCL_CLR    GPIO_ResetBits(sI2C_PORT, sI2C_SCL_PIN)
#define sI2C_SCL_SET    GPIO_SetBits(  sI2C_PORT, sI2C_SCL_PIN)

#define sI2C_SDA_CLR    GPIO_ResetBits(sI2C_PORT, sI2C_SDA_PIN)
#define sI2C_SDA_SET    GPIO_SetBits(  sI2C_PORT, sI2C_SDA_PIN)

#define sI2C_SDA_GET    GPIO_ReadInputBit(sI2C_PORT, sI2C_SDA_PIN)


EXTERN void    sI2cInit( void );
EXTERN uint8_t sI2cReadByte( uint8_t sla, uint8_t suba );
EXTERN uint8_t sI2cWriteByte( uint8_t sla, uint8_t suba, uint8_t dat );


#endif


