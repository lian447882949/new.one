#define __SPIOSD_C__


#include "SPIFlash.h"
#include "SPIOSD.h"
#include "TW8836.h"



const uint8_t SpiOsdWinBase[9] =
{
    SPIOSD_WIN0_START, SPIOSD_WIN1_START, SPIOSD_WIN2_START,
    SPIOSD_WIN3_START, SPIOSD_WIN4_START, SPIOSD_WIN5_START,
    SPIOSD_WIN6_START, SPIOSD_WIN7_START, SPIOSD_WIN8_START,
};

uint8_t SpiOsdWinRegs[10 * 0x10];

SPIOSD  gtSpiOsd;


extern uint8_t gucSpiFlash4ByteMode;
extern uint8_t SPICMD_x_READ;
extern uint8_t SPICMD_x_BYTES;


void SpiOsdEnable( uint8_t en )
{
    TW8836_WritePage(TW8836_PAGE4_SPI_OSD);

    if(en)
    {
        TW8836_Write(REG400, TW8836_Read(REG400) | 0x04);
    }
    else
    {
        TW8836_Write(REG400, TW8836_Read(REG400) & 0xFB);
    }
}


void SpiOsdSetDeValue( void )
{
    uint16_t temp = 0;
    uint8_t  HDE  = 0, PCLK0 = 0;

    TW8836_WritePage(TW8836_PAGE2_SCALER);

    HDE   = TW8836_Read(REG210);
    PCLK0 = TW8836_Read(REG20D) & 0x03;

    temp  = HDE + PCLK0 - 18;

    TW8836_WritePage(TW8836_PAGE4_SPI_OSD);
    TW8836_Write(REG40E, (uint8_t)(temp >> 0x08));
    TW8836_Write(REG40F, (uint8_t)(temp >> 0x00));
}


void SpiOsdWinEnable( uint8_t winno, uint8_t en )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    if(en) *dat |= 0x01;
    else   *dat &= 0xFE;
}


void SpiOsdAlphaBlending( uint8_t winno, uint8_t en, uint8_t mode, uint8_t alpha )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    if(en)   *dat |= 0x10;
    else     *dat &= 0xEF;

    if(mode) *dat |= 0x20;  /*Per Pixel Alpha*/
    else     *dat &= 0xDF;  /*Global Window 1 Alpha*/

    dat += SPIOSD_WIN_ALPHA;

    if(winno == 0) dat += 4;

    *dat = alpha;
}


void SpiOsdSetBitsPixel( uint8_t winno, uint8_t bpp )
{
    uint8_t *dat = gtSpiOsd.reg[winno];
    uint8_t mode = 0;

    if(bpp == 4)      mode = 0;
    else if(bpp == 6) mode = 1;
    else              mode = 2;

    *dat &= 0x3F;
    *dat |= (mode << 6);
}


void SpiOsdLutOffset( uint8_t winno,  uint8_t lut_offset )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    dat += SPIOSD_WIN_LUT_PTR;

    if(winno == 0) dat += 4;

    *dat = lut_offset >> 4;
}


void SpiOsdBuffWidth( uint8_t winno, uint16_t w, uint16_t h )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    uint8_t temp = 0;

    dat += SPIOSD_WIN_DISPSIZE;

    if(winno)
    {
        temp = *dat & 0xC0;
        *dat++ = (uint8_t)(w >> 8 | temp);
        *dat++ = (uint8_t)(w);
    }
    else
    {
        temp   = (uint8_t)(h >> 8);
        temp <<= 4;
        temp  |= (uint8_t)(w >> 8);

        *dat++ = temp;
        *dat++ = (uint8_t)w;
        *dat++ = (uint8_t)h;
    }
}


void SpiOsdSpiStartAddress( uint8_t winno, uint32_t address )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    dat += SPIOSD_WIN_BUFFERSTART;

    *dat++ = (uint8_t)(address >> 20);
    *dat++ = (uint8_t)(address >> 12);
    *dat   = (uint8_t)(address >> 4 );

    if(winno == 0) dat += 0x0E;
    else           dat += 0x06;

    *dat   = (uint8_t)(address & 0x0F);
}


void SpiOsdWindowPosAndSize( uint8_t winno, uint16_t start_h, uint16_t start_v, uint16_t len_h, uint16_t len_v )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    uint8_t temp = 0;

    dat += SPIOSD_WIN_WINDOW;

    temp   = (start_v >> 8);
    temp <<= 4;
    temp  |= (start_h >> 8);

    *dat++ = temp;
    *dat++ = (uint8_t)start_h;
    *dat++ = (uint8_t)start_v;

    temp   = (len_v >> 8);
    temp <<= 4;
    temp  |= (len_h >> 8);

    *dat++ = temp;
    *dat++ = (uint8_t)len_h;
    *dat++ = (uint8_t)len_v;
}


void SpiOsdZoom( uint8_t winno, uint8_t en )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    if(en) *dat |= 0x02;
    else   *dat &= 0xFD;
}


void SpiOsdFillColor( uint8_t winno, uint8_t en, uint8_t fill_color )
{
    uint8_t *dat = gtSpiOsd.reg[winno];

    if(en) *dat |= 0x04;
    else   *dat &= 0xFB;

    dat += SPIOSD_WIN_FILLCOLOR;

    *dat = fill_color;
}


void SpiOsdSetLut( uint8_t winno, uint8_t type, uint16_t lut_offset, uint16_t size, uint32_t addr, uint8_t alpha )
{
    SPIOSD_LUT *lut = &gtSpiOsd.lut[winno];

    lut->type   = 0x80 | type;
    lut->offset = lut_offset;
    lut->size   = size;
    lut->addr   = addr;
    lut->alpha  = alpha;
}


void SpiOsdSetRlc( uint8_t winno, uint8_t bpp, uint8_t counter )
{
    SPIOSD_RLC *rlc;

    if(winno == 0)
    {
        return;
    }

    if((winno == 1) || (winno == 2))
    {
        rlc = &gtSpiOsd.rlc[1]; /*Group B*/
    }
    else
    {
        rlc = &gtSpiOsd.rlc[0]; /*Group A*/
    }

    rlc->winno   = winno;
    rlc->bpp     = bpp;
    rlc->counter = counter;
}


void SpiOsdInit( void )
{
    uint8_t winno = 0, offset = 0;

    for(winno = 0; winno < 9; winno++)
    {
        if(winno) offset = winno + 0x01;
        else      offset = 0x00;

        gtSpiOsd.reg[winno] = &SpiOsdWinRegs[offset << 0x04];
    }

    SpiOsdClrLut();
    SpiOsdClrReg();
    SpiOsdClrRlc();

    SpiOsdUpdateReg(0, 8);
    SpiOsdUpdateRlc();
}


void SpiOsdClrReg( void )
{
    uint8_t i = 0;

    for(i = 0; i < 10 * 0x10; i++)
    {
        SpiOsdWinRegs[i] = 0x00;
    }
}


void SpiOsdClrLut( void )
{
    uint8_t winno = 0;

    SPIOSD_LUT *lut;

    for(winno = 0; winno < 9; winno++)
    {
        lut = &gtSpiOsd.lut[winno];

        lut->type   = 0;
        lut->offset = 0;
        lut->size   = 0;
        lut->addr   = 0;
        lut->alpha  = 0xFF;
    }
}


void SpiOsdClrRlc( void )
{
    uint8_t i = 0;

    SPIOSD_RLC *rlc;

    for(i = 0; i < 2; i++)
    {
        rlc = &gtSpiOsd.rlc[i];

        rlc->winno   = 0;
        rlc->bpp     = 0;
        rlc->counter = 0;
    }
}


void SpiOsdUpdateReg( uint8_t begin_winno, uint8_t end_winno )
{
    uint8_t i = 0, winno = 0, reg = 0;

    uint8_t *dat;

    TW8836_WritePage(TW8836_PAGE4_SPI_OSD);

    for(winno = begin_winno; winno <= end_winno; winno++)
    {
        dat = gtSpiOsd.reg[winno];
        reg = SpiOsdWinBase[winno];

        for(i = 0; i < 0x10; i++)   TW8836_Write(reg+i, dat[i]);

        if(winno == 0)
        {
            for( ; i < 0x17; i++)   TW8836_Write(reg+i, dat[i]);
        }
    }
}


void SpiOsdUpdateLut( uint8_t winno, uint8_t alpha )
{
    SPIOSD_LUT *lut;

    uint8_t  ucType = 0;

    uint8_t  ucTemp = 0;
    uint16_t uiTemp = 0;
    uint32_t ulTemp = 0;


    lut  = &gtSpiOsd.lut[winno];

    ucType = lut->type;

    if((ucType & 0x80) == 0x00) return;

    ucType &= SPIOSD_LUT_MASK;

    if(ucType == SPIOSD_LUT_ADDR) return;


    TW8836_WritePage(TW8836_PAGE4_SPI_OSD);

    ucTemp = SPIOSD_LUT_WEN;

    if(ucType == SPIOSD_LUT_ADDR) ucTemp |= SPIOSD_LUT_INC_ADDR;
    else                          ucTemp |= SPIOSD_LUT_INC_BYTE;

    if((winno == 1) || (winno == 2))
    {
        ucTemp |= SPIOSD_LUT_SEL;
    }
    else
    {
        if(lut->offset & 0x0F00)
        {
            ucTemp |= SPIOSD_LUT_ADDR_H;
        }
    }


    /*8-BIT SPIOSD Look Up Table Access Control*/
    TW8836_Write(REG410, ucTemp);

    /*8-BIT SPIOSD Look Up Table Address*/
    TW8836_Write(REG411, (uint8_t)(lut->offset));

    /*Flash Busy Control : No Busy Check & Read Mode*/
    TW8836_Write(REG4C4, 0x00);

    /*DMA Control Register*/
    SpiFlashDmaControl(DMA_RW_DEST_SOSD_LUT, DMA_RW_MODE_INCREASE, SPICMD_x_BYTES + gucSpiFlash4ByteMode);


    /*DMA Page & Index Register*/
    uiTemp = lut->offset;
    
    if(ucType == SPIOSD_LUT_ADDR)
    {
        TW8836_Write(REG4C6, (uint8_t)(uiTemp >> 8));
        TW8836_Write(REG4C7, (uint8_t)(uiTemp));
    }
    else
    {
        TW8836_Write(REG4C6, (uint8_t)(uiTemp >> 6));
        TW8836_Write(REG4C7, (uint8_t)(uiTemp << 2));
    }


    /*DMA Length High , MID, Low Byte*/
    uiTemp = lut->size;

    TW8836_Write(REG4DA, 0x00);
    TW8836_Write(REG4C8, (uint8_t)(uiTemp >> 8));
    TW8836_Write(REG4C9, (uint8_t)(uiTemp));


    /*DMA Command Buffer*/
    ulTemp = lut->addr;

    TW8836_Write(REG4CA, SPICMD_x_READ);

    if(gucSpiFlash4ByteMode)
    {
        TW8836_Write(REG4CB, (uint8_t)(ulTemp >> 24));
        TW8836_Write(REG4CC, (uint8_t)(ulTemp >> 16));
        TW8836_Write(REG4CD, (uint8_t)(ulTemp >> 8));
        TW8836_Write(REG4CE, (uint8_t)(ulTemp));
    }
    else
    {
        TW8836_Write(REG4CB, (uint8_t)(ulTemp >> 16));
        TW8836_Write(REG4CC, (uint8_t)(ulTemp >> 8));
        TW8836_Write(REG4CD, (uint8_t)(ulTemp));
    }


    /*DMA Start*/
    TW8836_Write(REG4C4, 0x01);


    if(alpha)
    {
        ucTemp = lut->alpha;

        if(ucTemp != 0xFF)
        {
            uiTemp += ucTemp;

            ucTemp = SPIOSD_LUT_WEN | SPIOSD_LUT_BYT;

            if((winno == 1) || (winno == 2))
            {
                ucTemp |= SPIOSD_LUT_SEL;
            }
            else
            {
                if(uiTemp >> 8)
                {
                    ucTemp |= SPIOSD_LUT_ADDR_H;
                }
            }

            TW8836_Write(REG410, ucTemp);
            TW8836_Write(REG411, (uint8_t)uiTemp);
            TW8836_Write(REG412, 0x7F);
        }
    }
}


void SpiOsdUpdateRlc( void )
{
    uint8_t i = 0, temp = 0;

    SPIOSD_RLC *rlc;

    TW8836_WritePage(TW8836_PAGE4_SPI_OSD);

    for(i = 0; i < 2; i++)
    {
        rlc = &gtSpiOsd.rlc[i];

        TW8836_Write(REG404 + i * 2, rlc->winno << 0x04);

        temp = rlc->bpp;

        if(temp == 7) temp++;

        temp <<= 0x04;

        temp |= (rlc->counter & 0x0F);

        TW8836_Write(REG405 + i * 2, temp);
    }
}



