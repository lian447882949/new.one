
#include "stm32f10x_usart.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
//#include "stm32f10x_nvic.h"


#include <string.h>
#include "IAPUsart.h"
#include "bsp.h"
#include "common.h"

#define	IAP_USART	USART1


void (*receChar)(u8 ch) = NULL;


//static SerialBuffType m_SendBuff = SerialBuffDefault();
//static SerialBuffType m_ReceBuff = SerialBuffDefault();

//static SerialBuffType *sb = &m_SendBuff;
//static SerialBuffType *rb = &m_ReceBuff;

static bool volatile eTXIdle = TRUE;

/*******************************************************************************
* Function Name :static s32 BspUsartxInit(void)
* Description   :���ڼ����ų�ʼ��
* Input         :
* Output        :
* Other         :
* Date          :2013.01.27
*******************************************************************************/
/*void BspUsart1Init(void)
{
    GPIO_InitTypeDef GpioInitdef;
    USART_InitTypeDef UsartInitdef;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);  

    USART_DeInit(USART1);

    USART_StructInit( &UsartInitdef );
    UsartInitdef.USART_BaudRate = 115200;
    UsartInitdef.USART_StopBits = USART_StopBits_1;
    UsartInitdef.USART_WordLength = USART_WordLength_8b;
    UsartInitdef.USART_Parity = USART_Parity_No;

    UsartInitdef.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &UsartInitdef);

    GpioInitdef.GPIO_Pin = GPIO_Pin_9; //
    GpioInitdef.GPIO_Speed = GPIO_Speed_10MHz;
    GpioInitdef.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GpioInitdef);

    GpioInitdef.GPIO_Pin = GPIO_Pin_10; //
    GpioInitdef.GPIO_Speed = GPIO_Speed_10MHz;
    GpioInitdef.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GpioInitdef);

    USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);


    USART_Cmd(USART1, ENABLE);
}

void BspUsart1Close(void)
{
    while (eTXIdle != TRUE);
    USART_Cmd(USART1, DISABLE);

    USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
    USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
    USART_ITConfig(USART1, USART_IT_TC, DISABLE);

    USART_ClearITPendingBit(USART1, USART_IT_TXE);
    USART_ClearITPendingBit(USART1, USART_IT_TC);
    USART_ClearITPendingBit(USART1, USART_IT_RXNE);	
}

*/
/*******************************************************************************
* Function Name :s32 BspUsartSend(u8* buf, u32 len)
* Description   :����һ���ַ���
* Input         :*buf:�ַ���ָ�롣len:����
* Output        :
* Other         :
* Date          :2012.05.11  11:45:38
*******************************************************************************/
u16 IAPUsartSend(u8 *buf, u16 len)
{
	u8 i,temp_len;
	temp_len = len;
    if( (temp_len > 0)  )
    {
    	for(i=0; i< temp_len; i++)
    	{
	        USART_SendData(IAP_USART, *buf);
	      //  eTXIdle = FALSE;
	      	buf++;
	        while (USART_GetFlagStatus(IAP_USART, USART_FLAG_TXE) == RESET);
    	}
        return TRUE;
    }

    return FALSE;
}

/*******************************************************************************
* Function Name :u16 BspUsart1Receive(u8 *buf)
* Description   :��ȡ���յ��ַ���
* Input         :buf: �������
* Output        :
* Other         :
* Date          :2013.02.20
*******************************************************************************/
//u16 BspUsart1Receive(u8 *buf)
//{
//    u16 len = rb->ind;
//    
//    memcpy(buf, rb->buf, len );
//    rb->ind = 0;
//
//    return len;
//}


/*******************************************************************************
* Function Name :void USART1_IRQHandler(void)
* Description   :USART1 �жϳ���
* Input         :
* Output        :
* Other         :
* Date          :2011.11.16  16:57:39
*******************************************************************************/
/*
void USART1_IRQHandler_Deal(void)
{
    if(SET == USART_GetITStatus(USART1, USART_IT_TXE))
    {
        USART_ClearITPendingBit(USART1, USART_IT_TXE);
        if (sb->len > 0 )
        {
            USART_SendData(USART1, sb->buf[sb->ind++]);
            sb->len--;
        }
        else
        {
            USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
            USART_ITConfig(USART1, USART_IT_TC, ENABLE);
        }
    }
    else if (USART_GetITStatus(USART1, USART_IT_TC) != RESET)
    {
        USART_ClearITPendingBit(USART1, USART_IT_TC);
        USART_ITConfig(USART1, USART_IT_TC, DISABLE);
        sb->len = 0;
        eTXIdle = TRUE;
    }
    else if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        u8 ch;
        
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);	
        ch = USART_ReceiveData(USART1);

//        if (rb->ind <USART1_BUFF_LANGTH)
//            rb->buf[rb->ind++] = ch;
        
        if (receChar != NULL)
            (*receChar)(ch);
    }	
}

*/

/********************** END ***************************************************/


