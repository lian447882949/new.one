#ifndef _DrvUsart1_h_
#define _DrvUsart1_h_

#include "stm32f10x.h"








void BspUsart1Init(void);
void BspUsart1Close(void);

u16 IAPUsartSend(u8 *buf, u16 len);
u16 BspUsart1Receive(u8 *buf);

u8 Usart1ReceiveByte(void);
void BspUsart1IRQCallBack(void *fun);


#endif
/********************** END ***************************************************/


