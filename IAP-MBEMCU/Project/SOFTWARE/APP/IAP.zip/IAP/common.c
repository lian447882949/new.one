/*-------------------------------------------------------------------------

                            �ӿڲ���
                            
                            
-------------------------------------------------------------------------*/

#include <string.h>

#include "stm32f10x_flash.h"
#include "YModem.h"
#include "common.h"
#include "Download.h"
#include "bsp.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
//static FunVoidType JumpToApplication;
static FunVoidType FunReceEnter = NULL;
static FunVoidType FunReceExit = NULL;
static FunWriteType FunWrite = NULL;
static FunProcessType FunCurrentProcess = NULL;

//static u32 m_JumpAddress;
static u32 m_ProgramAddr = BackupAddress;
volatile SerialBuffType m_ReceData = SerialBuffDefault();

static volatile eCOM_STATUS m_Mode = eCOMChoose;
static vu32 m_FlashAddress = 0;
static vu32 m_ExtFlashCounter = 0;       //�ⲿFLASH������������

u8 pArray[1028] = {0,};

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/



/*******************************************************************************
* Function Name :static void Print(u8 *str)
* Description   :��ӡ��Ϣ  ���ڷ���
* Input         :
* Output        :
* Other         :
* Date          :2013.03.01
*******************************************************************************/
void IAP_Print(u8 *str)
{
    u16 len = 0;

    len = strlen((const char *)str);

    while (IAPUsartSend(str, len) != TRUE);
}


/*******************************************************************************
* Function Name :void ReceOneChar(u8 ReceCharacter)
* Description   :���յ�һ���ַ�
* Input         :
* Output        :
* Other         :
* Date          :2013.02.19
*******************************************************************************/
void ReceOneChar(u8 ReceCharacter)
{
    if (m_ReceData.ind >= USART1_BUFF_LANGTH)
        return;
        
    if (m_ReceData.len > 0)
        return;
        
    m_ReceData.buf[m_ReceData.ind++] = ReceCharacter;
    BspTim3Open();      //��ʱ�����¼���
}

/*******************************************************************************
* Function Name :static void TimEndHandle(void)
* Description   :�����ַ���ʱ�ص�����
* Input         :
* Output        :
* Other         :
* Date          :2013.02.19
*******************************************************************************/
/*
static void TimEndHandle(void)
{
    BspTim3Close();

    m_ReceData.len = m_ReceData.ind;
    m_ReceData.ind = 0;
}
*/

void SoftReset(void)
{
	__set_FAULTMASK(1);      // �ر������ж�
	NVIC_SystemReset();// ��λ
}


/*******************************************************************************
* Function Name :void JumpToApp(void)
* Description   :��ת��Ӧ�ó�����
* Input         :None
* Output        :None
* Other         :None
* Date          :2013.02.19
*******************************************************************************/
/*
static void JumpToApp(void)
{
    if (((*(vu32*)ApplicationAddress) & 0x2FFE0000 ) == 0x20000000)
    { 
        BspClose();
        // Jump to user application 
        m_JumpAddress = *(vu32*) (ApplicationAddress + 4);
        JumpToApplication = (FunVoidType) m_JumpAddress;

        // Initialize user application's Stack Pointer 
        __MSR_MSP(*(vu32*) ApplicationAddress);
        JumpToApplication();
    }
}
*/


/*******************************************************************************
* Function Name :static void AppChoose(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
* Description   :����ѡ��   300ms���� �յ� �ַ�C ����bootload��
* Input         :
* Output        :
* Other         :
* Date          :2013.02.26
*******************************************************************************/
/*
static void AppChoose(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
{

    static u8 flg = 0;
    
    if (*pLen > 0)
    {
        if ((*pData == 'C') || (*pData == 'c'))
        {
            if (flg == 0)
                flg++;

            if (flg && IS_TIMEOUT_1MS(eTim1, 200))  //����ȷ��
                *peStat = eCOMDisplay;
        }
        *pLen = 0;
    }
    
    if (IS_TIMEOUT_1MS(eTim2, 320))
    {
        JumpToApp(); 
        IAP_Print("\n\r����ʧ��!");
        while (1);
     }
     
}
*/
/*******************************************************************************
* Function Name :static void DisplayMessage(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
* Description   :��ʾ��ʾ��Ϣ
* Input         :
* Output        :
* Other         :
* Date          :2013.02.26
*******************************************************************************/
/*
static void DisplayMessage(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
{

}

*/
/*******************************************************************************
* Function Name :static void InputSelect(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
* Description   :����ѡ��
* Input         :
* Output        :
* Other         :
* Date          :2013.02.26
*******************************************************************************/
static void InputSelect(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
{
    if (*pLen > 0)
    {
        switch (*pData)
        {
        case '1': 
            m_ProgramAddr = BackupAddress; 
            FunReceEnter = FLASH_ProgramStart;
            FunWrite = FLASH_WriteBank;
            FunReceExit = FLASH_ProgramDone;
            *peStat = eCOMReceive;
            IAP_Print("1\r\n��ѡ��Ҫ�����ļ�");
            break;    
            
        case '2': 
//            *peStat = eCOMChoose; 
//            Print("2\r\n���г���...");
            break;    
            
        default :break;
        }
        *pLen = 0;
    }
}



/*******************************************************************************
* Function Name :static void ReceiveData(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
* Description   :YModemЭ��������ݣ����洢����
* Input         :
* Output        :
* Other         :
* Date          :2013.02.26
*******************************************************************************/
static void ReceiveData(u8 *pData, u32 *pLen, volatile eCOM_STATUS *peStat)
{
	
    int len = 0;
    //pArray ��Ч������ len��Ч�����ݳ���
    switch (YmodemReceive((char *)(pData), (int *)pLen, (char *)pArray, (int *)&len))
    {
    case YM_FILE_INFO: 
        if (FunReceEnter) (*FunReceEnter)();    //��ʼ���� ����Flash��
        IS_TIMEOUT_1MS(eTimExitRec, 0);
        break;
        
    case YM_FILE_DATA: 
        if (FunWrite) (*FunWrite)(pArray, m_ProgramAddr, len);  //�������ݺ��� дһ֡���ݵ�Flash
        m_ProgramAddr += len;
		IS_TIMEOUT_1MS(eTimExitRec, 0);
        break;
        
    case YM_EXIT: 
        if (FunReceExit) (*FunReceExit)();      //������Ϻ��� FLASH_Lock
        FunCurrentProcess = eCOMChoose;
        FunReceEnter = NULL;
        FunWrite = NULL;
        FunReceExit = NULL;
        *peStat = eCOMChoose;
//        Print("\r\nϵͳ��λ!!");
//		SoftReset();
		
        break;
    }

}

/*******************************************************************************
* Function Name :void CommonInit(void)
* Description   :�ӿڳ�ʼ��
* Input         :
* Output        :
* Other         :
* Date          :2013.02.19
*******************************************************************************/
void CommonInit(void)
{
  //  BspTim3SetIRQCallBack(TimEndHandle);
  //  BspUsart1IRQCallBack(ReceOneChar);
}


/*******************************************************************************
* Function Name :void CommonExec(void)
* Description   :�ӿں���
* Input         :
* Output        :
* Other         :
* Date          :2013.02.20
*******************************************************************************/
void CommonExec(void)
{
    switch (m_Mode)
    {
    case eCOMChoose:    //�жϽ��� IAP���� ����APP����
 //       FunCurrentProcess = AppChoose;
 //       break;
        
    case eCOMDisplay:   //IAP������ʾ
 //       FunCurrentProcess = DisplayMessage;
 //       break;
        
    case eCOMInput:     //IAP����ѡ��
        FunCurrentProcess = InputSelect;
		IS_TIMEOUT_1MS(eTimExitRec, 0);
        break;

    case eCOMReceive:   //YMODEM ��������
        FunCurrentProcess = ReceiveData;
		if(IS_TIMEOUT_1MS(eTimExitRec, 10000))
			m_Mode = eCOMInput;	//10s��û�������յ����˳�����
        break;
        
    default:
        m_Mode = eCOMInput;
        break;
    }
    (*FunCurrentProcess)((u8 *)(m_ReceData.buf), (u32 *)&(m_ReceData.len), &m_Mode);
}




/*********************************** END **************************************/

